const CONFIG = {
  BASE_URL: 'https://restaurant-api.dicoding.dev/',
  DEFAULT_LANGUAGE: 'en-us',
};

export default CONFIG;
